package motorcycles;

import java.util.Scanner;

import com.sun.jdi.InvalidTypeException;

public class main {
	public static void main(String[] args) throws InvalidTypeException {

		/**
		 * Getting input data
		 * 
		 */

		Scanner sc = new Scanner(System.in);
		String answer;
		
		/**
		 * Doing a loop that allow's us to restart the program
		 */

		do {
			
			/**
			 * Checking the input data and giving results
			 */
			
			System.out.println("What type do you want: Motocross or Racebike");
			String mtype = sc.next();
			System.out.println("Type what brand do you want: \nYamaha\nHonda\nKawasaki\nSuzuki\nKTM ");
			String mname = sc.next();
			System.out.println("How much do you want to buy?");
			int am = sc.nextInt();
			if (mname.equals("Yamaha") || mname.equals("Honda") || mname.equals("Suzuki") || mname.equals("KTM")
					|| mname.equals("Kawasaki") && mtype.equals("Motocross") || mtype.equals("Racebike")) {
				if (mtype.equals("Motocross")) {
					if (mname.equals("Yamaha")) {
						Motorcycle yamaha = new Motoparam("YZ125", "Blue", 55, 125, "Japan", 40);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								yamaha.getModel(), yamaha.getColor(), yamaha.getHorsePower(), yamaha.getEngineVolume(),
								yamaha.countryProduced()));
						yamaha.buy(am);
					} else if (mname.equals("Honda")) {
						Motorcycle honda = new Motoparam("CR125", "Red", 45, 125, "Japan", 30);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								honda.getModel(), honda.getColor(), honda.getHorsePower(), honda.getEngineVolume(),
								honda.countryProduced()));
						honda.buy(am);
					} else if (mname.equals("Suzuki")) {
						Motorcycle suzuki = new Motoparam("RM125", "Yellow", 47, 125, "Japan", 20);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								suzuki.getModel(), suzuki.getColor(), suzuki.getHorsePower(), suzuki.getEngineVolume(),
								suzuki.countryProduced(), suzuki.getAmount()));
						suzuki.buy(am);
					} else if (mname.equals("KTM")) {
						Motorcycle ktm = new Motoparam("SX125", "Orange", 40, 125, "Austria", 15);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								ktm.getModel(), ktm.getColor(), ktm.getHorsePower(), ktm.getEngineVolume(),
								ktm.countryProduced()));
						ktm.buy(am);
					} else if (mname.equals("Kawasaki")) {
						Motorcycle kawasaki = new Motoparam("KX125", "Green", 50, 125, "Japan", 10);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								kawasaki.getModel(), kawasaki.getColor(), kawasaki.getHorsePower(),
								kawasaki.getEngineVolume(), kawasaki.countryProduced()));
						kawasaki.buy(am);
					}

				} else if (mtype.equals("Racebike")) {
					if (mname.equals("Yamaha")) {
						Motorcycle yamaha = new Motoparam("R1", "Blue", 145, 1000, "Japan", 40);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								yamaha.getModel(), yamaha.getColor(), yamaha.getHorsePower(), yamaha.getEngineVolume(),
								yamaha.countryProduced()));
						yamaha.buy(am);
					} else if (mname.equals("Honda")) {
						Motorcycle honda = new Motoparam("CBR1000", "Red", 100, 1000, "Japan", 30);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								honda.getModel(), honda.getColor(), honda.getHorsePower(), honda.getEngineVolume(),
								honda.countryProduced()));
						honda.buy(am);
					} else if (mname.equals("Suzuki")) {
						Motorcycle suzuki = new Motoparam("GSXR600", "Yellow", 90, 600, "Japan", 20);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								suzuki.getModel(), suzuki.getColor(), suzuki.getHorsePower(), suzuki.getEngineVolume(),
								suzuki.countryProduced(), suzuki.getAmount()));
						suzuki.buy(am);
					} else if (mname.equals("KTM")) {
						Motorcycle ktm = new Motoparam("Duke350", "Orange", 50, 350, "Austria", 15);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								ktm.getModel(), ktm.getColor(), ktm.getHorsePower(), ktm.getEngineVolume(),
								ktm.countryProduced()));
						ktm.buy(am);
					} else if (mname.equals("Kawasaki")) {
						Motorcycle kawasaki = new Motoparam("Ninja1000", "Green", 150, 1000, "Japan", 10);
						System.out.println(String.format(
								"We have the %s that is %s and have %d horsepowers.It is %dcc and it's made in %s.",
								kawasaki.getModel(), kawasaki.getColor(), kawasaki.getHorsePower(),
								kawasaki.getEngineVolume(), kawasaki.countryProduced()));
						kawasaki.buy(am);
					}
				}
				System.out.println("Do you want to start again? Yes or No");
				answer = sc.next();
			} else {

				/**
				 * Throwing exception if the inputed data is incorrect
				 */

				throw new InvalidTypeException("Invalid input data");
			}
		} while (answer.equals("Yes"));
	}
}
