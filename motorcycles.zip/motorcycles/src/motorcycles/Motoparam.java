package motorcycles;

public class Motoparam implements Motorcycle {
	
	/**
	 * Adding variables
	 */
	
	private String model;
	private String color;
	private int horsepower;
	private int enginevolume;
	private String country;
	private int amount;

	/**
	 * Constructor
	 */

	public Motoparam(String model, String color, int horsepower, int enginevolume, String country, int amount) {
		super();
		this.model = model;
		this.color = color;
		this.horsepower = horsepower;
		this.enginevolume = enginevolume;
		this.country = country;
		this.amount = amount;
	}

	/**
	 * Implementing
	 */

	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return this.model;
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return this.color;
	}

	@Override
	public Integer getHorsePower() {
		// TODO Auto-generated method stub
		return this.horsepower;
	}

	@Override
	public Integer getEngineVolume() {
		// TODO Auto-generated method stub
		return this.enginevolume;
	}

	@Override
	public String countryProduced() {
		// TODO Auto-generated method stub
		return this.country;
	}

	@Override
	public Integer getAmount() {
		return this.amount;
	}

	/**
	 * Buy method
	 */

	public void buy(int a) {
		if (amount - a < 0) {
			System.out.format("Unfortunately we have only %d bikes left.", amount);
		} else {
			System.out.format("They are left %d bikes and they will be %d if you buy %d.\n", amount, amount - a, a);
		}

	}
}