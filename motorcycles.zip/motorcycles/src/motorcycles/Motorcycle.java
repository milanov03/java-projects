package motorcycles;

import java.io.Serializable;

public interface Motorcycle extends Serializable {

	/**
	 * Adding methods
	 */

	String getModel();

	String getColor();

	Integer getHorsePower();

	Integer getEngineVolume();

	String countryProduced();

	Integer getAmount();

	void buy(int i);
}
